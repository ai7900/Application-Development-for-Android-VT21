package com.example.exercise31;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ArrayAdapter;

public class MainActivity extends AppCompatActivity {

    public static FragmentManager fragmentManager;

    /*
    * If you save the state of the application in a bundle,
    * it can be passed back to onCreate if the activity needs
    * to be recreated so that you don't lose this prior information.
    * If no data was supplied, savedInstanceState is null.
    */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeComponents();
    }

    private void initializeComponents(){

        fragmentManager = getSupportFragmentManager();
        BookFragment booksFrag = (BookFragment)fragmentManager.findFragmentById(R.id.fragment);
        AuthorFragment authorFrag = (AuthorFragment)fragmentManager.findFragmentById(R.id.fragment2);

        Controller controller = new Controller(booksFrag, authorFrag);
        booksFrag.setController(controller);


        FragmentTransaction fragmentTransaction;

        fragmentTransaction = fragmentManager.beginTransaction();
        BookFragment bFrag = new BookFragment();
        fragmentTransaction.add(R.id.fragment, bFrag, null);
        fragmentTransaction.commit();

/*        fragmentTransaction = fragmentManager.beginTransaction();
        AuthorFragment aFrag = new AuthorFragment();
        fragmentTransaction.add(R.id.fragment2, aFrag, null);
        fragmentTransaction.commit();*/

/*        fragmentTransaction = fragmentManager.beginTransaction();
        BookFragment bFrag = new BookFragment();
        AuthorFragment aFrag = new AuthorFragment();
        fragmentTransaction.add(R.id.fragment, bFrag, null);
        fragmentTransaction.add(R.id.fragment2, aFrag, null);
        fragmentTransaction.commit();*/
    }



}